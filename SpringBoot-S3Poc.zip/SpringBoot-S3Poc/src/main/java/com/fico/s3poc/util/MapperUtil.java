package com.fico.s3poc.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class MapperUtil {
	
	private static File convertMultiPartToFile(MultipartFile file) throws IOException {
	    File convFile = new File(file.getOriginalFilename());
	    FileOutputStream fos = new FileOutputStream(convFile);
	    fos.write(file.getBytes());
	    fos.close();
	    return convFile;
	}

}
