package com.fico.s3poc.service;

public interface ObjectStorageService {
	
	// Upload the file
	public String uploadFile(MultipartFile multipartFile) throws IOException;
	
	public String deleteFileFromS3Bucket(String fileUrl);

}
